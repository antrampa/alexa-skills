module.exports = [
  'Eliza, Michael and Antonis are the best team' ,
  'Eliza is the sister of Michael',
  'Michael is the brother of Eliza',
  'Michael is genius',
  'Eliza is smart',
  'Michael and Eliza are the kids of Antonis',
  'Eliza and Michael are both smart',
  'Eliza is beautiful',
  'Michael has a sister'        
];
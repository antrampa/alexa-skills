
import boto3
import botocore
import json
from botocore.vendored import requests

def get_weather():
    API_KEY = "your_openweathermap_api_key"  # Replace with your API Key
    CITY = "Thessaloniki"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"
    
    temp = "25"
    description = "Chilly with increasing clouds"
    return f"The current temperature in {CITY} is {temp}°C with {description}."
    # response = requests.get(url)
    # data = response.json()

    # if response.status_code == 200:
    #     temp = data["main"]["temp"]
    #     description = data["weather"][0]["description"]
    #     return f"The current temperature in {CITY} is {temp}°C with {description}."
    # else:
    #     return "Sorry, I couldn't fetch the weather."

def lambda_handler(event, context):
    intent_name = event["request"]["intent"]["name"]
    
    if intent_name == "GetWeatherIntent":
        speech_text = get_weather()
    else:
        speech_text = "Sorry, I didn't understand that."

    return {
        "version": "1.0",
        "response": {
            "outputSpeech": {
                "type": "PlainText",
                "text": speech_text
            },
            "shouldEndSession": True
        }
    }
